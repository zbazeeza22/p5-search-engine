#!/usr/bin/env python3

import sys


current_key = None
current_count = 0 

for line in sys.stdin:
    key, value = line.strip().split("\t")
    value = int(value) 


    if key != current_key:
        if current_key is not None:
            print(f"{current_key}\t{current_count}")
        current_key = key
        current_count = 0

    current_count += value

# Print the last key
if current_key is not None:
    print(f"{current_key}\t{current_count}")





 