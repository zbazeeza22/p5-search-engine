#!/usr/bin/env python3
import sys

for line in sys.stdin:
    term_doc, tf = line.strip().split("\t")
    term, docid = term_doc.split()

    print(f"{docid}\t{term} {tf}")
