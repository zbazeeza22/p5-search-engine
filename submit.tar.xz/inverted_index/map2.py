#!/usr/bin/env python3

import sys

for line in sys.stdin:

    docid, text = line.strip().split("\t",1) 

    terms = text.split() 

    for term in terms: 
        key = f"{term} {docid}" 
        print(f"{key}\t1")

