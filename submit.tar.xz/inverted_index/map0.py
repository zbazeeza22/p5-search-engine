#!/usr/bin/env python3
import sys

# Emit "1\t1" exactly once per document.
for line in sys.stdin:
    if "<!DOCTYPE html>" in line:
        print("1\t1")
